/* generated configuration header file - do not edit */
#ifndef R_CGC_CFG_H_
#define R_CGC_CFG_H_
#define CGC_CFG_MAIN_OSC_WAIT (5)
#define CGC_CFG_MAIN_OSC_CLOCK_SOURCE (0)
#define CGC_CFG_OSC_STOP_DET_USED SYNERGY_NOT_DEFINED
#define CGC_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define CGC_CFG_SUBCLOCK_DRIVE (0)
#define CGC_CFG_SUBCLOCK_AT_RESET_ENABLE (1)
#define CGC_CFG_USE_LOW_VOLTAGE_MODE (0)
#endif /* R_CGC_CFG_H_ */
