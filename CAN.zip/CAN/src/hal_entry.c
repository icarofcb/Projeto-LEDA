/* HAL-only entry function */
#include "hal_data.h"

static can_frame_t can_tx;
static can_frame_t can_rx;
uint32_t bilada;

void canCallback(can_callback_args_t *p_args)
{
    if(&p_args->event==CAN_EVENT_RX_COMPLETE)
    {
        g_can0.p_api->read(g_can0.p_ctrl,bilada,(can_frame_t *)&can_rx);
    }
}

void hal_entry(void)
{
    ssp_err_t err;

    err = g_can0.p_api->open(g_can0.p_ctrl,g_can0.p_cfg);

    if(SSP_SUCCESS != err)
    {

    }

    while(1)
    {
        R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);
    }
}
